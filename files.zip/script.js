// ============================
// Footer year
// ============================
document.getElementById('year').textContent = new Date().getFullYear();

// ============================
// Typing animation for hero name
// ============================
(function typeName() {
  const el = document.getElementById('typedName');
  const text = "Shreyas G D";
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (prefersReduced) {
    el.textContent = text;
    return;
  }

  let i = 0;
  function step() {
    if (i <= text.length) {
      el.textContent = text.slice(0, i);
      i++;
      setTimeout(step, 80);
    }
  }
  step();
})();

// ============================
// Mobile menu toggle
// ============================
const menuToggle = document.getElementById('menuToggle');
const tabs = document.getElementById('tabs');
menuToggle.addEventListener('click', () => {
  tabs.classList.toggle('open');
});
tabs.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => tabs.classList.remove('open'));
});

// ============================
// Active tab highlighting on scroll
// ============================
const sections = document.querySelectorAll('.section');
const tabLinks = document.querySelectorAll('.tab');

const navObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const id = entry.target.getAttribute('id');
      tabLinks.forEach(tab => {
        tab.classList.toggle('active', tab.getAttribute('href') === `#${id}`);
      });
    }
  });
}, { rootMargin: '-40% 0px -50% 0px', threshold: 0 });

sections.forEach(section => navObserver.observe(section));

// ============================
// Scroll reveal for sections
// ============================
const revealEls = document.querySelectorAll('.reveal');
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

revealEls.forEach(el => revealObserver.observe(el));

// ============================
// Skill bar fill animation
// ============================
const skillFills = document.querySelectorAll('.skill-fill');
const skillObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const fill = entry.target;
      fill.style.width = fill.dataset.level + '%';
      skillObserver.unobserve(fill);
    }
  });
}, { threshold: 0.4 });

skillFills.forEach(fill => skillObserver.observe(fill));

// ============================
// Contact form (front-end only demo)
// ============================
const form = document.getElementById('contactForm');
const formNote = document.getElementById('formNote');

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  formNote.textContent = `Thanks${name ? ', ' + name : ''} — this form is a front-end demo. Connect it to a backend or a service like Formspree to receive real messages.`;
  form.reset();
});

// ============================
// Resume download placeholder
// ============================
document.getElementById('resumeBtn').addEventListener('click', (e) => {
  e.preventDefault();
  alert('Add your resume PDF and update this button\'s href / file to enable downloading.');
});
